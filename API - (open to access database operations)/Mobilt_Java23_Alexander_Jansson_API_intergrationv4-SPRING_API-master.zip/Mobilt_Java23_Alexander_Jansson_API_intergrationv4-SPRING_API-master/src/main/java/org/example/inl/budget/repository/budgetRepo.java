package org.example.inl.budget.repository;

public interface budgetRepo {
}
