package org.example.inl.users.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class userDTO {

    private String email;
    private String password;

    public userDTO() {}



}
