package org.example.inl.budget.controller;

public class regBudgetGoal {
}
