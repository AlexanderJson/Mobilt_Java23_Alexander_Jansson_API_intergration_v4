package org.example.inl.budget.service;

public class budgetService {
}
