package org.example.inl.budget.model;

public class budget {
}
